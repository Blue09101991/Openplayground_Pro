const config = {
    firebase: {
        apiKey: "AIzaSyARiM_h7ceg4sfifpPMC05P0r0yr3ix8tg",
        authDomain: "focus-app-9adab.firebaseapp.com",
        databaseURL: "https://focus-app-9adab-default-rtdb.firebaseio.com",
        projectId: "focus-app-9adab",
        storageBucket: "focus-app-9adab.appspot.com",
        messagingSenderId: "1095720158953",
        appId: "1:1095720158953:web:32cdd88fa415528d6c5278",
        measurementId: "G-GLY9Q7RC09"
    }
}

export default config;
