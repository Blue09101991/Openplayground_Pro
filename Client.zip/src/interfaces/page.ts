export default interface IPageProps {
    name: string;
}